# MADI GRID - paczka dla GitHuba

Wygenerowano: 2026-08-11 11:33:06

Ta paczka zawiera aktualny stan aplikacji MADI GRID bez folderow tymczasowych:
- bez `node_modules`
- bez `.next`
- bez logow i plikow build cache

## Uruchomienie lokalne

```bash
npm install
npm run dev
```

Domyslny adres aplikacji:

```text
http://127.0.0.1:3000
```

## Build produkcyjny

```bash
npm run build
npm run start
```

## Zakres plikow

Paczka zawiera kod aplikacji Next.js/React, style CSS, pliki konfiguracyjne oraz skrypt eksportu.
Wykryte rozszerzenia: (no extension), .css, .gz, .html, .jpg, .js, .json, .md, .mjs, .png, .py, .svg, .ts, .tsx, .txt, .woff2, .yaml

## Aktualizacja paczki

Po zmianach uruchom:

```bash
python scripts/export_github_package.py
```

Wynik pojawi sie w folderze `exports`.
